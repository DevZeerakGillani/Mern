import Counter from "./Counter";

const App = () => {
  return <Counter />;
};

export default App;
