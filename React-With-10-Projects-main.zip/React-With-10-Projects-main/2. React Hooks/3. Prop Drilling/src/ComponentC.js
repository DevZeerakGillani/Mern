const ComponentC = ({ name }) => {
  return <h1>{name}</h1>;
};

export default ComponentC;
