function App() {
  return <h1>Component 🤝</h1>;
}

export default App;
