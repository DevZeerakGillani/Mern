import "./index.css";

const App = () => {
  return (
    <section>
      <h1>Seperate File For Styling</h1>
    </section>
  );
};

export default App;
