// 👉 https://react-icons.github.io/react-icons
// 👉 npm install react-icons --save
// 👉 import { AiOutlineHourglass } from "react-icons/ai";
// 👉  <AiOutlineHourglass />

import { AiOutlineHourglass } from "react-icons/ai";

const App = () => {
  return (
    <h1>
      <AiOutlineHourglass />
    </h1>
  );
};

export default App;
